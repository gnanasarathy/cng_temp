function redirectPage(page) {
    if (page == 'chat')
    {
        window.location.href = "/chat";
    }
    else if(page == 'quote')
    {
        window.location.href = "/quote";            
    }
    else if(page == 'analytics')
    {
        window.location.href = "/analytics";            
    }
    else if(page == 'holder')
        {
            window.location.href = "/holder";            
        }
}