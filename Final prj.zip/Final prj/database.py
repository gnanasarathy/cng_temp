"""SQLAlchemy DB instance"""
from flask_sqlalchemy import SQLAlchemy
db = SQLAlchemy()
